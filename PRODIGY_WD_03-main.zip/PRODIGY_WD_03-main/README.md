# PRODIGY_WD_03

To build a tic-tac-toe web application, you can use HTML, CSS, and JavaScript.
By implementing functions to handle user clicks, track game state, and check for winning conditions, you can create an interactive and engaging tic-tac-toe game. 
With these technologies and functionalities, users can play against each other or against an Al opponent, aiming to get three markers in a row to win the game.
